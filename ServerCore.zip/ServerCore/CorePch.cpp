#include "pch.h"
#include "CorePch.h"

void HelloServer()
{
	std::cout << "Hello Server" << std::endl;
}